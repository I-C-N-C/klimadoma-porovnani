# Klima Doma — Blueprint

Open `index.html` to preview. This folder is a standalone static site; upload all files in this folder together. It includes its own stylesheet and privacy page.

The form is a local demo and never sends or stores data. Before production, connect a secure server-side handler, replace all `XXX` values, confirm the controller identity and retention practice, and update the privacy notice with the real host and email provider. Photos still load from Wix; self-host approved copies to avoid that third-party request.
