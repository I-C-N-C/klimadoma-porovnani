# Klima Doma — Gridline

Open `index.html` to preview. This folder is self-contained: publish the files in this folder together, keeping `styles.css` and `privacy.html` beside `index.html`.

The form is a local demo and never sends or stores data. Before launch, connect a secure server-side form handler, replace every `XXX` in `privacy.html`, verify the controller identity and retention period, and update the notice to name the actual host and email provider. Photos still load from Wix and disclose visitor IP addresses to that provider; self-host approved copies to remove that request.
