# Klima Doma — Vivid Klima

Open `index.html` to preview. This folder is a standalone static site; upload all files in this folder together. It includes its own stylesheet and privacy page.

This variant combines Vivid's soft split layout with the reference site's free site visit, service details, installation locations, trust points, and six-photo gallery. The form is a local demo and never sends or stores data. Before production, replace all `XXX` values and verify the privacy notice. Hero and about photos load from Wix; project photos load from the existing `i-c-n-c.github.io/test-page` site.
