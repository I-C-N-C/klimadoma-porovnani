# Klima Doma — porovnání návrhů

Tento adresář je připravený jako obsah kořene samostatného veřejného GitHub repozitáře. Nahraj do nového repozitáře celý jeho obsah včetně podsložek. `index.html` otevře `porovnani.html`; šest návrhů a jejich zásady zůstávají v samostatných složkách.

## GitHub Pages

V repozitáři otevři **Settings → Pages**. Jako zdroj vyber **Deploy from a branch**, větev `main` a složku `/ (root)`, potom ulož. Po zveřejnění bude přehled na `https://i-c-n-c.github.io/klimadoma-porovnani/`.

Formuláře jsou pouze ukázkové a nic neposílají. Stránky záměrně obsahují pracovní zásady s údaji `XXX`; před použitím jako skutečného firemního webu je nahraď ověřenými údaji. Fotografie se načítají z Wixu.